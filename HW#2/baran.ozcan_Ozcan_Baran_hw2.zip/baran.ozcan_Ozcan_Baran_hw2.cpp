//Baran �zcan

//neccessary libraries and the namespace
#include <iostream>
#include <fstream>
#include <cctype>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>
#include <chrono>
#include <ctime>
using namespace std;

//Struct of flights carry many information;
struct flight{
  string from;string to;int hour;int min;int price;int ID;
  flight *next ;flight *prev ;
  
  //create withouth any info, make sure pointers are null so no errors during execution;
  flight() { next = nullptr; prev = nullptr; }

  //to create a flgiht object form the info in the list
  flight(string InputFrom, string InputTo, int InputHour,int InputMin, int InputPrice) {
      from = InputFrom;to = InputTo;hour = InputHour;min = InputMin;price = InputPrice;
      ID = 0;next=nullptr, prev = nullptr;}

};

//same logic with the flight constructors. Nothing fancy
struct airline{
  string name;
  int ID=0;
  airline *next;
  flight *flights;

  airline(){next = nullptr;flights = nullptr;}

  airline(string InputName) {
      name = InputName;}
};


//the count for the flight ID's, increased every time a new flight added, not touched when removed
int BIGTOTAL=-1;
//same for the airline ID's
int AIRLINETOTAL =-1;

//function prototypes, their definition and use are defined in the implementation part of the code.
void print_all(airline*&);
void add_flight_with_input(airline*&);
void remove_flight_with_input(airline*&);


//Function given by the course instructor, not updated.
//precondition: Bool value that is true if the files are already read, false if they are not read
//postcondition: warning if files are already read(also empty vectors),
//if files are not read returns 2 vectors, airline and flights of that airline, 
//function: reads given files and stores the flights in it in to the vectors.
pair<vector<string>, vector<vector<flight>>> read_files(bool input_done){
  
  ///READ FLIGHTS///
  vector<string> airlines;
  vector<vector<flight>> flights(100); //start with a previously sized vector or you get seg fault (for sure)
  
  //read through the files until you fail input_done 
  while(not input_done){
    
      //create variables and stream, get the name of the airline and its file
    string airline_name;
    string filename;
    cout << "Enter the name of airline: ";
    cin >> airline_name;
    cout << "Enter the name of airline file: ";
    cin >> filename;
    ifstream input(filename);

    //if user enters done as the filename, finish reading and return what is read so far
    if(filename == "done"){
      input_done = true;
      return make_pair(airlines, flights);
    }
    
    //if user enters a file name that is not valid ask again the above, until succession.
    while( input.fail() ){
      cout << "Could not open file: " << filename << endl;
      cout << "Enter the name of airline: ";
      cin >> airline_name;
      cout << "Enter the name of airline file: ";
      cin >> filename;
      input.open(filename);

      if(filename == "done"){
      input_done = true;
      return make_pair(airlines, flights);
      }
    }
    
    //add the new airline to the airline vectors
    airlines.push_back(airline_name);
    
    //indicate that the file found succesfullty 
    cout << "Processing input file: " << filename <<endl;
    
    //read the lines 5 by 5 and put neccesarry information in to a flight obejct
    //after object is created add it to the vactor of that airlines flights.
    int line_no = 0;
    vector<string> lines;
    string line;
    int vector_location = airlines.size() - 1;
    while(getline(input, line)){
      lines.push_back(line);
      line_no += 1;
      if(line_no % 5 == 0){
	flight a_flight(lines[line_no-5], lines[line_no-4], stoi(lines[line_no-3]), stoi(lines[line_no-2]), stoi(lines[line_no-1]));
	flights[vector_location].push_back(a_flight);
      }
    }
  }
  //indicate the end of the reading
  if(input_done){
    cout << "Input files are already read, however you can do manual changes.." << endl;
  }

  //return created vectors to the program
  return make_pair(airlines, flights);
}


//precondition = 2 vectors, one including the ariline names, one including the flights of all airlines,
//postcondition= an airline pointer to the first airline, thourgh this pointer we can reach a 2D-linked list structure for all airlines
//function= converting all data in the vektors into 2d linked list structure, the main linklist 
//holds airline nodes and reached by head, and each airline node carries a head for the linked list
//for flights of that airline in an ascending order in time.
airline* make_linked_list_structure(vector<string> airlines, vector<vector<flight>> flights){
    
    //define and initialise the pointer that we are going to return as head.
    airline* head = nullptr;

    //create an airline obj for all airlines in the string vector of airlines.
    head = new airline();
    airline* temp = head;

    for (int i = 0; i < airlines.size();i++ ) {
        //keep ID as a global variable
        AIRLINETOTAL++;
        temp->ID = AIRLINETOTAL;
        temp->name = airlines[i];
        //for the last item just nullptr dont allocate a new momory
        if (i == (airlines.size() - 1)) { temp->next =nullptr; }
        else { temp->next = new airline(); }
        temp = temp->next;
    }
    
    //we will again itterate for flights 
    temp = head;

    //we keep index for the airline number
    int index = 0;
    while (temp) {
        //�nitial setting create first flight
        temp->flights = new flight();
        flight* currentFlight = temp->flights;
        flight* tempPrev = nullptr; //first flights previous is nullptr
        
        //for each flight conncet the linkelist and add the values to the node
        for (int i = 0; i < flights[index].size(); i++ ) {
            //add values
            currentFlight->from = flights[index][i].from;
            currentFlight->to = flights[index][i].to;
            currentFlight->hour = flights[index][i].hour;
            currentFlight->min = flights[index][i].min;
            currentFlight->price = flights[index][i].price;
            BIGTOTAL++;
            currentFlight->ID = BIGTOTAL;
            
            //if not at the end of the flights, create memory for a new flight
            if (i != (flights[index].size()-1)) { currentFlight->next = new flight(); }
            
            //update connections
            currentFlight->prev = tempPrev;
            tempPrev = currentFlight;
            currentFlight = currentFlight->next;
        } 
        //move to the next ariline
        temp = temp->next;
        index++;
    }

    ///now we have to sort the list = i will use bublesort
    //main idea = why change the pointers when you can change the values.

    //back to start
    temp = head;

    //travel thorugh the airlines we  will sort airline by airline
    while (temp) {
        
        //create 2 flights and one condition, use explained in the process.
        bool sorted;
        flight* Dummy;
        flight* RightFlight=nullptr;

       
        if (temp == nullptr || temp->flights == nullptr) {
            // list contains 1 or 0 elements os it is alread sorted, pass this airline
        }

        else {
            //if the list of flights not empty
            do {
                sorted = false; //assume the flights are not sorted
                
                Dummy = temp->flights;//dummy is the first flight in the list 
                while (Dummy->next != RightFlight) { //right flight is the last flight of the list at hte start
                    
                    //compare their time
                    if ((Dummy->hour > Dummy->next->hour) || ((Dummy->hour == Dummy->next->hour) && (Dummy->min > Dummy->next->min))) {

                        //Change the values since the prev one is bigger than the last one
                        swap(Dummy->from,Dummy->next->from);
                        swap(Dummy->to, Dummy->next->to);
                        swap(Dummy->ID, Dummy->next->ID);
                        swap(Dummy->price, Dummy->next->price);
                        swap(Dummy->hour, Dummy->next->hour);
                        swap(Dummy->min, Dummy->next->min);
                        sorted = true;//if a sorting done the list is not sorted completely, do the loop again
                    }
                    Dummy = Dummy->next;
                    
                }
                //since the last element is sorted now shitf the last element to left.
          
                RightFlight = Dummy;

            } while (sorted); //do it untill its sorted


        }

        //go to the next airline
        temp = temp->next;
    }

    //all lists are sorted so return the head.
    return head;
}


//precondition = refrance to an airline pointer that functions as the head of the all data,
//what is the departure point, and what is the desired destination,
//what is the current cos of the route(initially 0),what is the current route(initially empty vector)
//what is the maximum number of transfers allowed and finnaly current transfer amount(initially 0)
//postcondition = a vetcor, intiger pair. Vector contains the flights we took in order, int is the total cost
//function = Finds the cheapest route wtih the given amount of maximum transfers form departure to destination.
pair<vector<flight>, int> RecursiveSearch(airline* head, string Departure, string Destination, int Currentcost, const vector<flight>& Route, int MaxTransfer, int CurrentTransfer) {
    
    //one closing case 
    //if we have landed in the destinatiion return the current route and the cost. 
    if (Departure == Destination) {
        return { Route, Currentcost };
    }

    //if we passed the allowed transfer, empty the road so we can understand this path didnt work later
    //in the same manner, make money so large that we can identify and eliminate this route.
    if (CurrentTransfer > MaxTransfer) {
        return { {}, numeric_limits<int>::max() };
    }

    //initialise a cheapest route and cost, use will be explined later
    int CheapestCost = numeric_limits<int>::max();
    vector<flight> CheapestRoute;

    //travel through the airlines
    airline* temp = head;
    while (temp) {
        //travel through the flights
        flight* tempflight = temp->flights;
        while (tempflight) {

            //if a flight takes of from where we are, that is a valid entry point for a route
            if (tempflight->from == Departure) {

                //add this flight to the current route and price, increment transfer by 1
                int NewCost = Currentcost + tempflight->price;
                int NewTransfer = CurrentTransfer + 1;

                //Try to add another flight to the route from the recursive call
                //this time parameters are updated according to the current route
                pair<vector<flight>, int> outcome = RecursiveSearch(head, tempflight->to, Destination, NewCost, Route, MaxTransfer, NewTransfer);


                //This is the important part that is confusing,  i will do extra explonations.
                //there are 2 ways that our recursion ends: finding a path, transfer number breached.
                //if transfer number is breached the cost is maximum, so is the CheapestCost in the initial.
                //so we fail the if statement below, and our outcome gets ignored, we try a new path.

                //IF we manage to reach our end within the scope of max travels, price of our outcome will
                //be some 'int' that is definitely not maximum. So we enter the if statement below. 
                //new cheapest cost becomes cost of this route, and chepaest route becomes this route as well
                //but destinaiton returns an empty route. so we add the flight with a pushback. 

                //IF though, our route is not the first valid route, above doesnt work, and prices of the 2 routes compared 
                //Since we made cheapest cost the most cheapest working route. If new route isnt cheaper than that
                //it gets ignored, and path continues. 

                if (outcome.second < CheapestCost) {
                    CheapestCost = outcome.second;
                    CheapestRoute = outcome.first;
                    CheapestRoute.push_back(*(tempflight));
                    
                }
            }

            tempflight = tempflight->next;
        }
        temp = temp->next;
    }
    //return the curretCheapestRoute and the Cheapest price,
    //Changed in this run or not doesnt matter since we have done the checks above, 
    return make_pair(CheapestRoute, CheapestCost);
}


//precondition = refrance to an airline pointer that functions as the head of the all data
//postcondition= returns 1, that will not be used, to indicate that the programm has runned succesfully
//function= takes a depatrure and destination point from the user, finds the cheapest route wilth limited
//number of transfers, which is also taken from the user.
int pathfinder(airline* head){

    //define relevant variables
    string from, to;
    int maxTransfer;
    pair<vector<flight>, int> route;//we will store the route and the total cost in this.
    
    //take neccesary input from the user
    cout << "Where are you now?"<<endl;
    cin >> from;
    cout << "Where do you want to go?" << endl;
    cin >> to;
    cout << "Maximum number of transfers:" << endl;
    cin >> maxTransfer;

    //call the recursive pathfinder DFS algorithm to find best route
    route = RecursiveSearch(head, from, to, 0, {}, maxTransfer,0);
    
    //cout the path from the route
    //since path is returned reversely we cout form reverse of the vector.
    flight CurrentFlight;
    if (route.first.size() == 0) { cout << "No path found between " << from << " and " << to << endl; }
    else {
    cout << "##Best price path##" << endl;
    for (int i = route.first.size() - 1; 0< i; i--) {
        CurrentFlight = route.first[i];
        cout << "[" << CurrentFlight.ID << "|" << CurrentFlight.from << "->" << CurrentFlight.to << "|" << CurrentFlight.hour << ":" << CurrentFlight.min << "|" << CurrentFlight.price << "]->";
    }
    
     CurrentFlight = route.first[0]; cout << "[" << CurrentFlight.ID << "|" << CurrentFlight.from << "->" << CurrentFlight.to << "|" << CurrentFlight.hour << ":" << CurrentFlight.min << "|" << CurrentFlight.price << "] $TOTAL PRICE: " << route.second;
    cout << endl;
    }
    
     
    return 1;
}


//precondition = refrance to an airline pointer that functions as the head of the all data
//postcondition = nothing, but the data stcurcure is modified,and head is nullified.
//funciton= deletes all the memory allocated by the flights, makes the head pointer null;
void delete_linked_list(airline* &head){

    //temperory variables to travel linkedlist.
    airline* temp= head;
    airline* tempAirline = nullptr;
    flight* tempFlight = nullptr;
    //flight* prev = nullptr;

    
    while (temp) {
        //travel thorugh the flights
        tempFlight = temp->flights;
        //move and delete in a single sweep
        while (tempFlight && tempFlight->next) {
            delete tempFlight->prev;
            tempFlight = tempFlight->next;    
        }
        delete tempFlight;
        tempFlight = nullptr;

        //delete the airline and move on to the next one
        tempAirline = temp->next;
        delete temp;
        temp = tempAirline;
    }
    //just in case
    head=nullptr;
}


//precondition = no paramters
//postcondition = no values
//function = cout an illustrated menu for user to navigate in the program.
void printMainMenu() {
  cout << endl;
  cout <<"I***********************************************I"<<endl
       <<"I               0 - DELETE DATA                 I"<<endl
       <<"I               1 - READ FILES                  I"<<endl
       <<"I               2 - PRINT ALL FLIGHTS           I"<<endl
       <<"I               3 - ADD FLIGHT                  I"<<endl
       <<"I               4 - REMOVE FLIGHT               I"<<endl
       <<"I               5 - PATH FINDER                 I"<<endl
       <<"I               6 - EXIT                        I"<<endl
       <<"I***********************************************I"<<endl
       <<">>";
  cout << endl;
}  


//Function given by the instrucutor
//Changes Done: input_done defined, initialised as false. airline*head initialised as nullptr.
//precondition: no parameters
//postcondition: no values
//function: hepls user to travell through the menu nad execute the functions
void processMainMenu() {

  //define the vectors that we initially store the flight data.
  //define the pointer that we will use as head of the linked-list structure.
  pair<vector<string>, vector<vector<flight>>> lines_flights;
  airline* head=nullptr;
 

  char input; //get inputs form the user
  bool input_done = false;  //keep track of whether the files are read or not
  
  //print the menu and according to user navigation execute the proper functions
  do{
    printMainMenu();
    cout << "Please enter your option " << endl;
    cin >> input;
    switch (input) {
    case '0'://deleate all data and nullify the head pointer.
      delete_linked_list(head);
      cout << "Data is destroyed.." << endl;
      input_done = false; //make it possible to read new files
      break;
    case '1'://read files and create the 2D doubly linkedlist data structure. 
      if(not input_done){
	    lines_flights = read_files(input_done);
	    head = make_linked_list_structure(lines_flights.first, lines_flights.second);
	    cout << "Files are read.." << endl;
      }
      else{
	    cout << "Files are already read.." << endl;
      }
      input_done = true;
      break;
    case '2'://cout all data avaliable
      print_all(head);
      break;
    case '3'://Add a flight to the linked list.
      add_flight_with_input(head);
      break;
    case '4': //remove a flight with its ID(asked during execution)
      remove_flight_with_input(head);
      break;
    case '5': //call to find a path
      pathfinder(head);
      break;
    case '6': //exit condition
      cout << "Exiting.." << endl;
      exit(0);
    default:
      cout << "Invalid option: please enter again" << endl;
    }
  } while(true);
}


//precondtion = no parameters
//postcondition = returns 0 if the programs is successfully executed
//function = calls a process main menu function in order to start our program in a loop within that function
int main(){
  processMainMenu();
  return 0;
}


//precondition = refrance to an airline pointer that functions as the head of the all data
//post condition = no values 
//function = Couts the airlines in order, and beneath each airlines their flighst are shown in
//increasing order in their flight time. Their price, ID, depatrue and arrival locations are also shown.
void print_all(airline *&head) {
    
    //create temperory pointers for flights and airlines to traverse thorugh the data.
    airline* temp = head;
    flight* tempFlight = nullptr;
    
    //if head is nullptr, indicate that are neither flights nor airlines.
    if (!head) { cout << "List is empty.." << endl; }

    //loop through the airlines untill you see nullptr, means end.
    while (temp) {

        //cout the airline data. 
        cout << "###################################" << endl;
        cout << "### AIRLINE ID: " << (*temp).ID << " ###"<<endl;
        cout << "NAME:" << (*temp).name << endl;
        cout << "FLIGHTS: ";
        
        //make starting ptr the first flight of the current airline
        tempFlight = temp->flights;
        
        //loop through the flights until you reach an end. 
        while (tempFlight)
        {
            //cout flight data
            cout << "#["<<tempFlight->ID<<"|" << tempFlight->from << "->" << 
            tempFlight->to << "|" << tempFlight->hour << ":" << tempFlight->min << 
            "|" << tempFlight->price <<"TRY]#";

            //go to the next flight
            tempFlight = tempFlight->next;
        }
        cout  << endl;
        //go to the next airline
        temp = temp->next;
    }

}


//precondition = refrance to an airline pointer that functions as the head of the all data
//postcondition = nothing, but the data stcurcure is modified. 
//function = ask user inputs, and according to details add a flight to an existing airline 
//time order will be kept during insertion
void add_flight_with_input(airline*& head) {

    //define and acquire and airline name from the user.
    string AirlineName;
    cout << "Adding manual entry:" << endl;
    cout << "AIRLINE: ";
    cin >> AirlineName;

    //increment the number of flights by 1, and update the data of the new flight with user inputs.
    flight* newFlight = new flight();
    BIGTOTAL++;
    newFlight->ID = BIGTOTAL;
    cout << "FROM: ";
    cin >> newFlight->from;
    cout << "TO: ";
    cin >> newFlight->to;
    cout << "HOUR: ";
    cin >> newFlight->hour;
    cout << "MIN: ";
    cin >> newFlight->min;
    cout << "PRICE: ";
    cin >> newFlight->price;
    cout << "Flight ID " << newFlight->ID << " is added to the list...";


    //Now we need to update the linkedlist
    // 
    //trough the airline linked-list find the pointer of that airline
    airline* currentAirline = head;
    while (currentAirline->name != AirlineName)
    {
        currentAirline = currentAirline->next;
        if (currentAirline == nullptr) { break; }
    }
    
    
    //it will be nullptr if no such airline exists
    if (!currentAirline) {
        //since it doesnt exist we add it
        airline* newAirline = new airline();
        AIRLINETOTAL++;
        newAirline->ID = AIRLINETOTAL;
        newAirline->name = AirlineName;
        newAirline->next = nullptr;
        //find the last airline in the original list, and insert new airline
        airline* lastAirline = head;
        while (lastAirline->next) {
            lastAirline = lastAirline->next;
        }
        lastAirline->next = newAirline;
        currentAirline = newAirline;
        currentAirline->flights = newFlight;
        newFlight->next = nullptr;
        newFlight->prev = nullptr;
    }
    
    //in the instance that there exists such airline
    else {
        //if the airline is empty, add it without any worries
        if (!(currentAirline->flights)) {
            currentAirline->flights = newFlight;
            newFlight->next = nullptr;
            newFlight->prev = nullptr;
        }      
        else {
            //go to the insertion place and add the new flight
            flight* currentFlight = currentAirline->flights;
            //obtain the after insertion flights pointer, flight after the new flight(time wise)
            //will return nullptr if new flight should be added to the end of the list
            while (currentFlight)
            {   
                if ((currentFlight->hour < newFlight->hour) || ((currentFlight->hour == newFlight->hour) && (currentFlight->min < newFlight->min)))
                {
                    currentFlight = currentFlight->next;
                }
                else { break; }
            }
            //not end of the list
            if (currentFlight) {
                flight* TempPrev = currentFlight->prev;
                flight* TempNext = currentFlight;
                //new flight is connected to previous flight and next flight;
                newFlight->prev = TempPrev;
                newFlight->next = TempNext;
                currentFlight->prev = newFlight;
                if (!newFlight->prev) { currentAirline->flights = newFlight; }//if to the start of the list
                else { newFlight->prev->next = newFlight; }//if in to the midle of the list
            }
            //end of the list connection, simple idea
            else {
                //first get the last flight
                flight* ddemo = currentAirline->flights;
                while (ddemo->next) {
                    ddemo = ddemo->next;
                }
                //then connect
                ddemo->next = newFlight;
                newFlight->prev = ddemo;
                newFlight->next = nullptr;
            }
        }
    }  
}


//precondition = refrance to an airline pointer that functions as the head of the all data
//postcondition = nothing, but the data stcurcure is modified. 
//function = A flight is found with the user given ID and hten the flight is removed and data is updated.
void remove_flight_with_input(airline*&head) {

    //get the ID from the user and cout neccesarry things. 
    int Remove;
    cout << "Flight id to remove: ";
    cin >> Remove;
    

    //start forom the first airline and loop through all the flights.
    airline* temp=head;
    airline* toRemoveFrom =nullptr ;//airline that we are removing from
    flight* currentFlight=nullptr;
    flight* toRemove = nullptr;

    //loop thorugh the airlines
    while (temp) {
        //enter the airline and loop throught the flights
        currentFlight = temp->flights;
        while (currentFlight) {
            //if ID matches, store a pointer to that flight.
            if (currentFlight->ID == Remove) {
                toRemove = currentFlight;
                toRemoveFrom = temp;
                break;
            }
            currentFlight = currentFlight->next;
        }
        temp = temp->next;
    }

    //if the flight that reequested to be removed exists, update the links of the linkedlist
    if (toRemove) {
        //if the only element of the airline
        if ((!(toRemove->next)) && (!(toRemove->prev))) {
            delete toRemove;
            toRemove = nullptr;
            toRemoveFrom->flights = nullptr;
        }
        //if airline has more than 1 flights and last one removed
        else if(!(toRemove->next)){
            toRemove = toRemove->prev;
            flight* dummy = toRemove->next;
            delete dummy;
            toRemove->next = nullptr;}
        //if airline has more than 1 flights and first one removed
        else if (!(toRemove->prev)) {
            flight* dummy = toRemove->next;
            delete toRemove;
            toRemove = dummy;
            toRemove->prev = nullptr;
            toRemoveFrom->flights = toRemove;
        }
        //if airline has more than 2 flights and a middle arbitrary one removed
        else {
            //store the prev and the nexts of the ToRemove
            flight* UpdatedPrev = toRemove->prev;
            flight* UpdatedNext = toRemove->next;
            //now add new likns
            toRemove->prev->next = UpdatedNext;
            toRemove->next->prev = UpdatedPrev;
            //get rid of the thing
            delete toRemove;
            
        }
        toRemove = nullptr; //as a precaution
    }


    //if doesnt exist get out 
    else { cout << "no flights with that ID exists"<< endl; return; }


    //now if an airline lost all flights get rid of it.
    temp = head;
    
    while (temp) {
        if (!(temp->flights)){
          
            //if this is the only airline
            if (temp == head && !(temp->next)) {
                delete temp;
                temp = nullptr;
                head = nullptr;
                break;
            }
            //if this is the last airline
            else if (!(temp->next)) {
                airline *prev=head;
                while (!(prev->next == temp)) { prev = prev->next; }//find airline before it
                delete temp;
                prev->next = nullptr;
                temp = nullptr;
                break;
            }
            //if this is the fisrt airline 
            else if (temp==head) {
                head = temp->next;
                delete temp;
                temp = head;
                break;
            }
            //if its in between
            else {
                //find previous and next airlines
                airline* prevA = head;
                while (!(prevA->next == temp)) { prevA = prevA->next; }
                airline* nextA = temp->next;
                delete temp;
                prevA->next = nextA;//connect them
                break;
            }
        }
        temp = temp->next;
    }

    //inform the user
    cout << "Flight ID " << Remove << " removed form the list";
}



